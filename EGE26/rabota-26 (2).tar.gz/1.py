
# считываем файл чисел и делаем копию
with open("26-J5.txt") as f:
	_ = f.readline()
	data = [int(x) for x in f]
	vals = data[:]

# последовательно высчитываем второе по величине значения и заменяем
for ind in range(len(data) - 2):
	vals[ind + 1] = sorted([vals[ind], data[ind + 1], data[ind + 2]])[1]

# количество наименьших значений
print(vals.count(min(vals)))

# сумма разностей, без учёта отрицательных разностей
print(sum(a - b for a, b in zip(data, vals) if a - b > 0))

