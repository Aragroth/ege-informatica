from statistics import mean, median

# считываем данные
with open("26-J2.txt") as f:
	_ = f.readline()
	data = sorted([int(x) for x in f])

# с каким числами будем сравнивать
compare = sorted([mean(data), int(median(data))])

# сколько чисел попадает под границы
print(len([val for val in data if compare[0] <= val <= compare[1]]))

